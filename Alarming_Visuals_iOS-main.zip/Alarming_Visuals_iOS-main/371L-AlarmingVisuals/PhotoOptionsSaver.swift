//
//  PhotoOptionsSaver.swift
//  371L-AlarmingVisuals
//
//  Created by Daniel Jeng on 10/30/23.
//

import Foundation

protocol PhotoOptionsSaver {
    func savePhotoOptions(option: String)
}
