//
//  CameraPreview.swift
//  371L-AlarmingVisuals
//
//  Created by Daniel Jeng on 10/13/23.
//

import UIKit

class CameraPreview: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
